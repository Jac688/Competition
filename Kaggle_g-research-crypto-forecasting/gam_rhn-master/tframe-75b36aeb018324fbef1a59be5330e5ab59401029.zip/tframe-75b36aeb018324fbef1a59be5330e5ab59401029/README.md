# tframe
A deep learning programming framework based on tensorflow

---
## Requirement
* tensorflow version >= 1.2

---
## Monitor mechanism

