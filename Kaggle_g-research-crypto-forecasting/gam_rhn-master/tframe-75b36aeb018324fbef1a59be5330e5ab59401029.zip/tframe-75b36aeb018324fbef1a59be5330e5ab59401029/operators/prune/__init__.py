"""
This package is for weight pruning.
It is temporally put inside `operators` package.
"""
