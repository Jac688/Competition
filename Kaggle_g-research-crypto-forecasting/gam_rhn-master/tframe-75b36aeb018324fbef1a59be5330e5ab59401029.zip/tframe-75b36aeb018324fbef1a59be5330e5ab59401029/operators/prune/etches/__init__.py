"""
ETCHES is a package containing high level pruning techniques developed by
tframe developer.
"""
from .etch_kernel import EtchKernel


get_etch_kernel = EtchKernel.get_etch_kernel


