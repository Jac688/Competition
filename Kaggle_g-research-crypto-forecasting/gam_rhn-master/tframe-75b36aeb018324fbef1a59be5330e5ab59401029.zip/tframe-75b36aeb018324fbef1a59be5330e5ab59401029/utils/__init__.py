from . import console
from . import local

from .misc import get_scale
from .misc import shape_string
from .note import Note

from tensorflow.python.framework import tensor_shape
